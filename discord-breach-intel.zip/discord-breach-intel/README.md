# Discord Breach Intelligence

A Next.js + Tailwind breach-intelligence dashboard for checking whether a Discord ID, username, email, or FiveM license appears in indexed breach/leak datasets.

## Setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Files

- `app/page.tsx` — GodsEye-style dashboard UI
- `app/api/breach-scan/route.ts` — server-side breach provider integration
- `.env.example` — provider API key template

## Important

This tool displays indexed breach records only. It does not prove that an account was compromised. Use it only for authorized security research, self-checks, or lawful moderation. Never expose passwords, credentials, or full personal data.
